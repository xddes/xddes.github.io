from app.handlers import help, ping, prefixes, info, online, status, trusted, wall_post, infector
from .rules import *
from .const import NOCMD, ALL_COMMANDS


@Global.user.on.message_handler(SelfCommand())
async def onselfcommand(msg: Message):
    prefix, command = await getparams(msg.text)
    main_cmd = 'no'
    firstcmd = command.split(' ', 1)
    firstcmd = firstcmd[0]
    for cmd in ALL_COMMANDS:
        if firstcmd in ALL_COMMANDS[cmd]:
            main_cmd = cmd
            break
    if main_cmd == 'no':
        await edit_message(
            msg,
            NOCMD
        )
    else:
        if main_cmd == 'help':
            await help.self_handle_help(msg)
        elif main_cmd == 'ping':
            await ping.self_handle_ping(msg, firstcmd)
        elif main_cmd == 'prefixes':
            await prefixes.self_handle_prefixes(msg, command)
        elif main_cmd == 'info':
            pass
        elif main_cmd == 'online':
            await online.self_handle_online(msg, command)
        elif main_cmd == 'status':
            await status.self_handle_status(msg, command)
        elif main_cmd == 'trusted':
            await trusted.self_handle_trusted(msg, command)
        elif main_cmd == 'wall_post':
            await wall_post.self_handle_wall_post(msg, command)
        elif main_cmd == 'infector':
            await infector.self_handle_infector(msg, command)
        else:
            print(f'caught self command {main_cmd}: {command}')
            await edit_message(
                msg,
                f'caught self command {main_cmd}: {command}'
            )



@Global.user.on.message_handler(TrustedCommand())
async def ontrustedcommand(msg: Message):
    prefix, command = await getparams(msg.text)
    main_cmd = 'no'
    firstcmd = command.split(' ', 1)
    firstcmd = firstcmd[0]
    for cmd in ALL_COMMANDS:
        if firstcmd in ALL_COMMANDS[cmd]:
            main_cmd = cmd
            break
    if main_cmd == 'no':
        await edit_message(
            msg,
            NOCMD
        )
    else:
        if main_cmd == 'help':
            await help.trusted_handle_help(msg)
        elif main_cmd == 'ping':
            await ping.trusted_handle_ping(msg, firstcmd)
        elif main_cmd == 'prefixes':
            await prefixes.self_handle_prefixes(msg, firstcmd)
        else:
            print(f'caught trusted command {main_cmd}: {command}')
            await edit_message(
                msg,
                f'caught trusted command {main_cmd}: {command}'
            )


@Global.user.on.message_handler(SelfDeleteCommand())
async def onselfdeletecommand(msg: Message):
    await edit_message(
        msg,
        "await get_ping(msg)"
    )


async def init_all():
    await infector.infector_start()
    await online.online_start()
    await status.status_start()
    await wall_post.wall_post_start()