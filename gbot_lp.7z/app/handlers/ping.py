from ..utils import *
import time


async def get_ping(msg: Message, cmd: str) -> str:
    ans = ''
    if cmd == 'пинг':
        ans = 'ПОНГ'
    elif cmd == 'кинг':
        ans = 'КОНГ'
    elif cmd == 'тик':
        ans = 'ТОК'
    elif cmd == 'пиу':
        ans = 'ПАУ'
    elif cmd == 'генг':
        ans = 'БЕНГ'
    elif cmd == 'хип':
        ans = 'ХОП'
    a = round(time.time(), 2)
    b = msg.date
    delta = round(time.time(), 2) - msg.date
    delta = "%.2f" % delta
    return f'{ans} епт\n{await getrandomsmile()} {delta} с {await getrandomsmile()}\n'


async def self_handle_ping(message: Message, cmd: str):
    await edit_message(
        message,
        await get_ping(message, cmd)
    )


async def trusted_handle_ping(message: Message, cmd: str):
    await message.api.messages.send(
        peer_id=message.peer_id,
        message=await get_ping(message, cmd),
        random_id=getrand()
    )