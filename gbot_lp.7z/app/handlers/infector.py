import threading

from ..utils import *
from threading import Thread
import time
import asyncio

infector_thread: Thread = None

async def infector_hint():
    text = f"""
    Автоматическая заражалка.
    
    Использование:
    {SMILES["KISS"]} {Global.DB.prefixes["self_prefix"]} заражалка [команда] [параметр]

    Алиасы:
    {SMILES["ROSE"]} — заражатель
    {SMILES["ROSE"]} — инфектор
    {SMILES["ROSE"]} — з
    {SMILES["ROSE"]} — и

    Команды: 
    {SMILES["WATER"]} — вкл | он | + | 1 — включить
    {SMILES["WATER"]} — выкл | офф | - | 0 — выключить
    {SMILES["WATER"]} — время | интервал | вр | инт [с] — интервал между заражениями в [c]
    {SMILES["WATER"]} — текст [текст] — писать [текст]
    {SMILES["WATER"]} — удалять — удалять свои сообщения
    {SMILES["WATER"]} — неудалять — неудалять

    Примеры: 
    {SMILES["ROSEB"]} {Global.DB.prefixes["self_prefix"]} з вкл
    {SMILES["ROSEB"]} {Global.DB.prefixes["self_prefix"]} и инт 42
    """.replace('    ', '')
    return text


async def infector_settings():
    text = f"""
    Автоматическая заражалка.

    Текущие настройки:
    {SMILES["KISS"]} Работает? {'Конечно работает' if Global.DB.infector["working"] else 'Нет а зачем'}
    {SMILES["WATER"]} Повторяет: {Global.DB.infector["text"]}
    {SMILES["LIPS"]} Каждые: {Global.DB.infector["sleep"]} с
    {SMILES["DEVIL"]} Сообщения{' ' if Global.DB.infector["delete_self_messages"] else ' не '}удаляются
    """.replace('    ', '')
    return text


async def infector_thread_func():
    while Global.DB.infector["working"]:
        answer = await Global.user._api.messages.send(
            peer_id=Global.DB.home_chat_id,
            message=Global.DB.infector["text"],
            random_id=await getrand()
        )
        time.sleep(10)
        if Global.DB.infector["delete_self_messages"]:
            await Global.user._api.messages.delete(
                message_ids=answer,
                delete_for_all=True,
                spam=False
            )
        time.sleep(Global.DB.infector["sleep"] - 10)


async def infector_start():
    if not Global.DB.infector["working"]:
        return
    global infector_thread
    infector_thread = Thread(target=asyncio.run, args=(infector_thread_func(),), daemon=True)
    infector_thread.start()


async def infector_stop():
    global infector_thread
    infector_thread.join(timeout=1)


async def self_handle_infector(message: Message, cmd: str):
    global infector_thread
    words = cmd.split(' ', 2)
    if len(words) == 2:
        if words[1] in ['вкл', 'он', '1', '+']:
            if Global.DB.infector["working"]:
                await edit_message(
                    message,
                    f'{SMILES["CLOWN"]} Заражалка уже работает!'
                )
            else:
                Global.DB.infector["working"] = True
                Global.DB.save()
                await infector_start()
                await edit_message(
                    message,
                    f'{SMILES["SUCCESS"]} Заражалка включена {SMILES["WOLF"]}'
                )
        elif words[1] in ['выкл', 'офф', '0', '-']:
            if not Global.DB.infector["working"]:
                await edit_message(
                    message,
                    f'{SMILES["CLOWN"]} Заражалка итак не работала'
                )
            else:
                Global.DB.infector["working"] = False
                Global.DB.save()
                await infector_stop()
                await edit_message(
                    message,
                    f'{SMILES["SUCCESS"]} Заражалка выключена {SMILES["CLOWN"]}'
                )
        elif words[1] == 'удалять':
            Global.DB.infector["delete_self_messages"] = True
            Global.DB.save()
            await edit_message(
                message,
                f'{SMILES["WOLF"]} Волк удаляет сообщения потому что захотел {await getrandomsmile()}'
            )
        elif words[1] == 'неудалять':
            Global.DB.infector["delete_self_messages"] = False
            Global.DB.save()
            await edit_message(
                message,
                f'{SMILES["WOLF"]} Волк не удаляет сообщения потому не захотел {await getrandomsmile()}'
            )
        elif words[1] in ['помощь', 'хелп', 'хелб']:
            await edit_message(
                message,
                await infector_hint()
            )
        else:
            await edit_message(
                message,
                f'{SMILES["WARNING"]} Чтото ктото пошел нетак.... правельно введи команду'
            )
    elif len(words) == 3:
        if words[1] in ['время', 'интервал', 'вр', 'инт']:
            timee = -1
            try:
                timee = int(words[2])
            except:
                pass
            if timee < 5:
                return await edit_message(
                    message,
                    f'{SMILES["WARNING"]} Чтото ктото пошел нетак.... правельно введи время'
                )
            Global.DB.infector["sleep"] = timee
            Global.DB.save()
            await infector_stop()
            await infector_start()
            await edit_message(
                message,
                f'{SMILES["WOLF"]} Теперь заражает каждые {timee} секунд {SMILES["DEVIL"]}'
            )
        elif words[1] == 'текст':
            Global.DB.infector["text"] = words[2]
            Global.DB.save()
            await edit_message(
                message,
                f'{SMILES["WOLF"]} Теперь повторяет текст: {words[2]}'
            )
    elif len(words) == 1:
        await edit_message(
            message,
            await infector_settings()
        )
    else:
        await edit_message(
            message,
            await infector_hint()
        )

