from ..utils import *


async def prefix_hint():
    text = f"""
    1. Собственный префикс: {Global.DB.prefixes["self_prefix"]}
    2. Доверенный префикс: {Global.DB.prefixes["repeat_prefix"]}
    3. Префикс удалятора: {Global.DB.prefixes["delete_prefix"]}
    
    Использование: 
    {SMILES["KISS"]} [префикс] префикс [номер] [новый префикс]
    
    Алиасы:
    {SMILES["ROSE"]} — префиксы
    {SMILES["ROSE"]} — префы
    {SMILES["ROSE"]} — преф
    
    Примеры: 
    {SMILES["ROSEB"]} {Global.DB.prefixes["self_prefix"]} префикс 2 я
    {SMILES["ROSEB"]} {Global.DB.prefixes["self_prefix"]} преф 1 ыыы
    """.replace('    ', '')
    return text

async def self_handle_prefixes(message: Message, cmd: str):
    words = cmd.split(' ')
    name = ''
    if len(words) == 3:
        words[2] = words[2].lower()
        if words[1] == '1':
            Global.DB.prefixes["self_prefix"] = words[2]
            name = 'Собственный префикс'
            Global.DB.save()
        elif words[1] == '2':
            Global.DB.prefixes["repeat_prefix"] = words[2]
            name = 'Доверенный префикс'
            Global.DB.save()
        elif words[1] == '3':
            Global.DB.prefixes["delete_prefix"] = words[2]
            name = 'Префикс удалятора'
            Global.DB.save()
        else:
            await edit_message(
                message,
                'Невалидный номер префикса!'
            )
            return
        if name != '':
            await edit_message(
                message,
                f'{name} был изменён на \"{words[2]}\".'
            )
    else:
        await edit_message(
            message,
            await prefix_hint()
        )
