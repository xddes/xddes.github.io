from ..utils import *


async def prefix_hint():
    a = 1
    ts = ''
    for trusted in Global.DB.trusted_users:
        name = await get_full_name_by_id(trusted)
        ts += f'{SMILES["SHIT"]} {a}. [id{trusted}|{name}]\n'
        a += 1
    if len(Global.DB.trusted_users) < 1:
        ts = f'{SMILES["DEVIL"]} Их нет!!1'
    text = f"""
    Доверенные пользователи:
    {ts}
    Использование: 
    {SMILES["KISS"]} [префикс] дов [команда] [@ссылка / ответ на сообщение]

    Алиасы:
    {SMILES["ROSE"]} — доверенные
    {SMILES["ROSE"]} — довы
    {SMILES["ROSE"]} — дов
    
    Команды: 
    {SMILES["WATER"]} — выдать | дать | + | 1 — сделать доверенным
    {SMILES["WATER"]} — забрать | взять | - | 0 — несделать

    Примеры: 
    {SMILES["ROSEB"]} {Global.DB.prefixes["self_prefix"]} дов дать @id363327274
    {SMILES["ROSEB"]} {Global.DB.prefixes["self_prefix"]} дов - (ответом)
    """.replace('    ', '')
    return text


async def self_handle_trusted(message: Message, cmd: str):
    words = cmd.split(' ', 2)
    if len(words) < 2:
        await edit_message(
            message,
            await prefix_hint()
        )
    else:
        if words[1] in ['выдать', 'дать', '1', '+']:
            ids = []
            if message.reply_message and message.reply_message.from_id != Global.DB.self_id:
                ids.append(message.reply_message.from_id)
            if len(words) == 3:
                links = await get_all_links_from_string(words[2])
                for link in links:
                    real_id = await get_id_from_link(link)
                    if real_id != 0 and real_id != Global.DB.self_id:
                        ids.append(real_id)
            if len(ids) > 0:
                if len(ids) == 1:
                    ts = ''
                    name = await get_full_name_by_id(ids[0])
                    if ids[0] > 0:
                        name = f'[id{ids[0]}|{name}]'
                    else:
                        name = f'[club{-ids[0]}|{name}]'
                    if ids[0] in Global.DB.trusted_users:
                        ts = f'{SMILES["CLOWN"]} {name} уже в доверенных.'
                    else:
                        ts = f'{SMILES["AUF"]} {name} теперь в доверенных.'
                        Global.DB.trusted_users.append(ids[0])
                    await edit_message(
                        message,
                        ts
                    )
                else:
                    ts = f'{SMILES["WOLF"]} Доверенных стало больше!\nСписок победителей по жизни:\n\n'
                    for member_id in ids:
                        name = await get_full_name_by_id(member_id)
                        if member_id > 0:
                            name = f'[id{member_id}|{name}]'
                        else:
                            name = f'[club{-member_id}|{name}]'
                        if member_id in Global.DB.trusted_users:
                            ts += f'{SMILES["CLOWN"]} {name} (уже есть) {await getrandomsmile()}\n'
                        else:
                            ts += f'{SMILES["AUF"]} {name} {await getrandomsmile()}\n'
                            Global.DB.trusted_users.append(member_id)
                    await edit_message(
                        message,
                        ts
                    )
                Global.DB.save()
            else:
                await edit_message(
                    message,
                    f'{SMILES["WARNING"]} Что-то я неправильно написал...'
                )
        elif words[1] in ['забрать', 'взять', '0', '-']:
            ids = []
            if message.reply_message and message.reply_message.from_id != Global.DB.self_id:
                ids.append(message.reply_message.from_id)
            if len(words) == 3:
                links = await get_all_links_from_string(words[2])
                for link in links:
                    real_id = await get_id_from_link(link)
                    if real_id != 0 and real_id != Global.DB.self_id:
                        ids.append(real_id)
            if len(ids) > 0:
                if len(ids) == 1:
                    ts = ''
                    name = await get_full_name_by_id(ids[0])
                    if ids[0] > 0:
                        name = f'[id{ids[0]}|{name}]'
                    else:
                        name = f'[club{-ids[0]}|{name}]'
                    if ids[0] not in Global.DB.trusted_users:
                        ts = f'{SMILES["CLOWN"]} {name} доверенным и не являлся.'
                    else:
                        ts = f'{SMILES["CLOWN"]} {name} теперь антидоверенное лицо.'
                        Global.DB.trusted_users.remove(ids[0])
                    await edit_message(
                        message,
                        ts
                    )
                else:
                    ts = f'{SMILES["SHIT"]} Доверенных стало меньше!\nСписок проигравших:\n\n'
                    for member_id in ids:
                        name = await get_full_name_by_id(member_id)
                        if member_id > 0:
                            name = f'[id{member_id}|{name}]'
                        else:
                            name = f'[club{-member_id}|{name}]'
                        if member_id not in Global.DB.trusted_users:
                            ts += f'{SMILES["AUF"]} {name} (и не было) {await getrandomsmile()}\n'
                        else:
                            ts += f'{SMILES["CLOWN"]} {name} {await getrandomsmile()}\n'
                            Global.DB.trusted_users.remove(member_id)
                    await edit_message(
                        message,
                        ts
                    )
                Global.DB.save()
            else:
                await edit_message(
                    message,
                    f'{SMILES["WARNING"]} Что-то я неправильно написал...'
                )
        else:
            await edit_message(
                message,
                await prefix_hint()
            )
