NAME = "GBot"
VERSION = "1.1"
AUTHOR = "[id363327274|Тахир]"
AUTHOR_SILENT = "[id363327274|&#8291;]"
DELIMITER = "==================="
API_VERSION = "5.131"

# wall
WALL_OWNER_ID = '-174105461'
WALL_POST_ID = '6713149'
WALL_MESSAGE = 'Ферма'

DEFAULT_DATABASE = {
    "token": "",
    "prefixes": {
        "self_prefix": "Г",
        "repeat_prefix": "Т",
        "delete_prefix": "ГГ"
    },
    "trusted_users": [],
    "delete_message": "не верь"
}
DEFAULT_PATH = "./config.json"

NOCMD = "Нет такой команды."
SMILES = {
    'SHIT': "💩",
    'KISS': "💋",
    'ROSE': "🌹",
    'ROSEB': "🥀",
    'WATER': "💦",
    'LIPS': "👄",
    'DEVIL': "😈",
    'CLOWN': "🤡",
    'AUF': "☝🏻",
    'WOLF': "🐺",
    'SUCCESS': "✅",
    'WARNING': "⚠",
    'ERROR': "❌"
}

ALL_COMMANDS = {
    'help': [
        'помощь',
        'хелп',
        'хелб'
    ],
    'prefixes': [
        'префиксы',
        'префикс',
        'префы',
        'преф'
    ],
    'ping': [
        'пинг',
        'кинг',
        'пиу',
        'тик',
        'генг',
        'хип'
    ],
    'info': [
        'инфо'
    ],
    'online': [
        'онлайн',
        'анал',
        'о'
    ],
    'status': [
        'статус',
        'стат'
    ],
    'trusted': [
        'дов',
        'довы',
        'доверенные'
    ],
    'deleter': [
        'удалятор',
        'уд',
        'делетер'
    ],
    'wall_post': [
        'постер',
        'пост',
        'ферма'
    ],
    'infector': [
        'з',
        'и',
        'заражалка',
        'заражатель',
        'инфектор'
    ],
    'get_lab': [
        'л',
        'лаб',
        'лаба',
        'лаборатория'
    ],
    'find_infections_by_id': [
        'заразы',
        'зы',
        'зз'
    ],
    'find_infections_by_name': [
        'патоген',
        'пы',
        'пп'
    ],
    'infect_replay': [
        'зарази',
        'зи',
        'ебни',
        'ёбни',
        'ебани'
    ],
    'autoinfect': [
        'автоответчик',
        'ао'
    ],
    'timer': [
        'таймер',
        'т'
    ]
}
