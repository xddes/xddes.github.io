from loguru import logger

logger.add('../logs/work.log', level='INFO')
