from vbml import PatchedValidators


class DefaultValidators(PatchedValidators):
    pass


DEFAULT_WAIT = 20
DEFAULT_BLUEPRINT = ("Unknown", "Simple Blueprint")
