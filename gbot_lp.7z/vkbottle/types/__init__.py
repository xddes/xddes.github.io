from vkbottle.types.events.events_objects import *
