__version__ = "2.7.12"

__author__ = "timoniq"

API_VERSION = "5.103"

API_URL = "https://api.vk.com/method/"

VERSION_REST = (
    "https://raw.githubusercontent.com/timoniq/vkbottle-rest/master/version.json"
)
