from vkbottle.framework import User
from vkbottle.types.user_longpoll import Message
from vkbottle.framework.blueprint.user import Blueprint
