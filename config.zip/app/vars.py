from .database import Database
from vkbottle.user import User, Message


class Global:
    DB = Database()
    DB.load()
    user = User(tokens=DB.tokens, expand_models=True)
    #user.api.throw_errors = False
    canwrite = True

