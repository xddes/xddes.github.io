import json
from .const import DEFAULT_DATABASE, DEFAULT_PATH
from .log import logger
import traceback
import sys


class Database:
    tokens = []
    prefixes = {
        "self_prefix": "",
        "repeat_prefix": "",
        "delete_prefix": ""
    }
    self_id = -1
    trusted_users = []
    delete_message = ""
    home_chat_id = -1
    main_bot_id = -1
    online = False
    status = False
    status_song = ""
    wall_post = False
    infector = {}

    def __init__(self):
        pass

    def load(self):
        template = ""
        try:
            with open(DEFAULT_PATH, encoding='utf-8') as f:
                template = json.load(f)
            self.tokens = template["tokens"]
            self.prefixes = template["prefixes"]
            self.self_id = template["self_id"]
            self.trusted_users = template["trusted_users"]
            self.delete_message = template["delete_message"]
            self.home_chat_id = template["home_chat_id"]
            self.main_bot_id = template["main_bot_id"]
            self.online = template["online"]
            self.status = template["status"]
            self.status_song = template["status_song"]
            self.wall_post = template["wall_post"]
            self.infector = template["infector"]
            logger.info('database loaded')
            return True
        except:
            logger.error(f'error while loading database:\n{traceback.format_exc()}')
            return False

    def save(self):
        template = {
            "tokens": self.tokens,
            "prefixes": self.prefixes,
            "self_id": self.self_id,
            "trusted_users": self.trusted_users,
            "delete_message": self.delete_message,
            "home_chat_id": self.home_chat_id,
            "main_bot_id": self.main_bot_id,
            "online": self.online,
            "status": self.status,
            "status_song": self.status_song,
            "wall_post": self.wall_post,
            "infector": self.infector
        }
        try:
            with open(DEFAULT_PATH, 'w', encoding='utf-8') as f:
                json.dump(template, f, ensure_ascii=False, indent=4)
            logger.info('database saved')
            return True
        except:
            logger.error(f'error while saving database:\n{traceback.format_exc()}')
            return False
