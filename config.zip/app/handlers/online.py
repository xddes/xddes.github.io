import threading

from ..utils import *
from threading import Thread
import time
import asyncio

online_thread: Thread = None


async def online_hint():
    text = f"""
    Модуль вечного онлайна.
    
    Использование:
    {SMILES["KISS"]} {Global.DB.prefixes["self_prefix"]} онлайн [команда]

    Алиасы:
    {SMILES["ROSE"]} — анал
    {SMILES["ROSE"]} — о

    Команды: 
    {SMILES["WATER"]} — вкл | он | + | 1 — включить онлайн
    {SMILES["WATER"]} — выкл | офф | - | 0 — выключить онлайн

    Примеры: 
    {SMILES["ROSEB"]} {Global.DB.prefixes["self_prefix"]} анал вкл
    {SMILES["ROSEB"]} {Global.DB.prefixes["self_prefix"]} о 0
    """.replace('    ', '')
    return text


async def online_thread_func():
    while Global.DB.online:
        await Global.user._api.account.set_online(voip=False)
        time.sleep(100)

async def online_start():
    if not Global.DB.online:
        return
    global online_thread
    online_thread = Thread(target=asyncio.run, args=(online_thread_func(),), daemon=True)
    online_thread.start()
    print('online started')

async def online_stop():
    global online_thread
    online_thread.join(timeout=1)


async def self_handle_online(message: Message, cmd: str):
    global online_thread
    words = cmd.split(' ')
    if len(words) == 2:
        if words[1] in ['вкл', 'он', '1', '+']:
            if Global.DB.online:
                await edit_message(
                    message,
                    f'{SMILES["CLOWN"]} Вечный онлайн уже работает'
                )
            else:
                Global.DB.online = True
                Global.DB.save()
                await online_start()
                await edit_message(
                    message,
                    f'{SMILES["SUCCESS"]} Вечный онлайн включен {SMILES["WOLF"]}'
                )
        elif words[1] in ['выкл', 'офф', '0', '-']:
            if not Global.DB.online:
                await edit_message(
                    message,
                    f'{SMILES["CLOWN"]} Вечный онлайн итак не работал'
                )
            else:
                Global.DB.online = False
                Global.DB.save()
                await online_stop()
                await edit_message(
                    message,
                    f'{SMILES["SUCCESS"]} Вечный онлайн выключен {SMILES["CLOWN"]}'
                )
        else:
            await edit_message(
                message,
                await online_hint()
            )
    elif len(words) == 1:
        hs = ''
        if Global.DB.online:
            hs = f'{SMILES["SUCCESS"]} Вечный онлайн работает'
        else:
            hs = f'{SMILES["WARNING"]} Вечный онлайн не работает'
        await edit_message(
            message,
            hs
        )
    else:
        await edit_message(
            message,
            await online_hint()
        )

