import threading

from ..utils import *
from threading import Thread
import time
import asyncio
from ..const import WALL_OWNER_ID, WALL_POST_ID, WALL_MESSAGE
import traceback

wall_post_thread: Thread = None

async def wall_post_hint():
    text = f"""
    Автоматическая ферма коинов.

    Использование:
    {SMILES["KISS"]} {Global.DB.prefixes["self_prefix"]} постер [команда]

    Алиасы:
    {SMILES["ROSE"]} — пост
    {SMILES["ROSE"]} — ферма

    Команды: 
    {SMILES["WATER"]} — вкл | он | + | 1 — включить
    {SMILES["WATER"]} — выкл | офф | - | 0 — выключить

    Примеры: 
    {SMILES["ROSEB"]} {Global.DB.prefixes["self_prefix"]} ферма вкл
    {SMILES["ROSEB"]} {Global.DB.prefixes["self_prefix"]} пост -
    """.replace('    ', '')
    return text


async def wall_post_thread_func():
    while Global.DB.wall_post:
        answer = await Global.user._api.wall.create_comment(
            owner_id=WALL_OWNER_ID,
            post_id=WALL_POST_ID,
            message=WALL_MESSAGE,
            guid=await getrand()
        )
        wall_comment_id = -1
        try:
            wall_comment_id = answer.comment_id
        except:
            logger.error(f'error from wall_post:\n{str(traceback.format_exc())}')
        time.sleep(10)
        await Global.user._api.wall.delete_comment(
            owner_id=WALL_OWNER_ID,
            comment_id=wall_comment_id
        )
        await Global.user._api.messages.send(
            peer_id=Global.DB.home_chat_id,
            message='wall done!',
            random_id=await getrand()
        )
        time.sleep(14450)

async def wall_post_start():
    if not Global.DB.wall_post:
        return
    global wall_post_thread
    wall_post_thread = Thread(target=asyncio.run, args=(wall_post_thread_func(),), daemon=True)
    wall_post_thread.start()

async def wall_post_stop():
    global wall_post_thread
    wall_post_thread.join(timeout=1)


async def self_handle_wall_post(message: Message, cmd: str):
    global wall_post_thread
    words = cmd.split(' ')
    if len(words) == 2:
        if words[1] in ['вкл', 'он', '1', '+']:
            if Global.DB.wall_post:
                await edit_message(
                    message,
                    f'{SMILES["CLOWN"]} Постер уже работает!'
                )
            else:
                Global.DB.wall_post = True
                Global.DB.save()
                await wall_post_start()
                await edit_message(
                    message,
                    f'{SMILES["SUCCESS"]} Постер включен {SMILES["WOLF"]}'
                )
        elif words[1] in ['выкл', 'офф', '0', '-']:
            if not Global.DB.wall_post:
                await edit_message(
                    message,
                    f'{SMILES["CLOWN"]} Постер итак не работал'
                )
            else:
                Global.DB.wall_post = False
                Global.DB.save()
                await wall_post_stop()
                await edit_message(
                    message,
                    f'{SMILES["SUCCESS"]} Постер выключен {SMILES["CLOWN"]}'
                )
        else:
            await edit_message(
                message,
                await wall_post_hint()
            )
    elif len(words) == 1:
        hs = ''
        if Global.DB.wall_post:
            hs = f'{SMILES["SUCCESS"]} Постер работает'
        else:
            hs = f'{SMILES["WARNING"]} Постер не работает'
        await edit_message(
            message,
            hs
        )
    else:
        await edit_message(
            message,
            await wall_post_hint()
        )

