from app.commands import *
import asyncio

if __name__ == '__main__':
    loop = asyncio.get_event_loop()
    loop.run_until_complete(init_all())
    Global.user.run_polling()
