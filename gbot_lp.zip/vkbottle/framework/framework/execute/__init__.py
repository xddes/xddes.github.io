from .definitions import converter, vkscript
