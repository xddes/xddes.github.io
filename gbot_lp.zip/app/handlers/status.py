import threading

from ..utils import *
from threading import Thread
import time
import asyncio

status_thread: Thread = None

async def status_hint():
    text = f"""
    Модуль вечного статуса (музыка).

    Использование:
    {SMILES["KISS"]} {Global.DB.prefixes["self_prefix"]} статус [команда]

    Алиасы:
    {SMILES["ROSE"]} — стат

    Команды: 
    {SMILES["WATER"]} — вкл | он | + | 1 — включить статус
    {SMILES["WATER"]} — выкл | офф | - | 0 — выключить статус

    Примеры: 
    {SMILES["ROSEB"]} {Global.DB.prefixes["self_prefix"]} статус вкл
    {SMILES["ROSEB"]} {Global.DB.prefixes["self_prefix"]} стат 0
    """.replace('    ', '')
    return text


async def status_thread_func():
    while Global.DB.status:
        ans = call_method("audio.setBroadcast", f"audio={Global.DB.status_song}", 1)
        #print(ans.json())
        time.sleep(100)

async def status_start():
    if not Global.DB.status:
        return
    global status_thread
    status_thread = Thread(target=asyncio.run, args=(status_thread_func(),), daemon=True)
    status_thread.start()

async def status_stop():
    global status_thread
    status_thread.join(timeout=1)


async def self_handle_status(message: Message, cmd: str):
    global status_thread
    words = cmd.split(' ')
    if len(words) == 2:
        if words[1] in ['вкл', 'он', '1', '+']:
            if Global.DB.status:
                await edit_message(
                    message,
                    f'{SMILES["CLOWN"]} Вечный статус уже работает'
                )
            else:
                Global.DB.status = True
                Global.DB.save()
                await status_start()
                await edit_message(
                    message,
                    f'{SMILES["SUCCESS"]} Вечный статус включен {SMILES["WOLF"]}'
                )
        elif words[1] in ['выкл', 'офф', '0', '-']:
            if not Global.DB.status:
                await edit_message(
                    message,
                    f'{SMILES["CLOWN"]} Вечный статус итак не работал'
                )
            else:
                Global.DB.status = False
                Global.DB.save()
                await status_stop()
                await edit_message(
                    message,
                    f'{SMILES["SUCCESS"]} Вечный статус выключен {SMILES["CLOWN"]}'
                )
        else:
            await edit_message(
                message,
                await status_hint()
            )
    elif len(words) == 1:
        hs = ''
        if Global.DB.status:
            hs = f'{SMILES["SUCCESS"]} Вечный статус работает'
        else:
            hs = f'{SMILES["WARNING"]} Вечный статус не работает'
        await edit_message(
            message,
            hs
        )
    else:
        await edit_message(
            message,
            await status_hint()
        )

