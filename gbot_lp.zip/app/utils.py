from .vars import Global
from vkbottle.rule import Message
from vkbottle import VKError
import random
from .const import SMILES, API_VERSION
from .log import logger
from requests import post
from time import sleep
from typing import Optional, List, Iterable
import re


async def getparams(stringtocheck: str):
    params = stringtocheck.split(' ', 1)
    if len(params) < 2:
        return "", ""
    params[0] = params[0].lower()
    params[1] = params[1].lower()
    for prefix in Global.DB.prefixes:
        if Global.DB.prefixes[prefix] == params[0]:
            return params[0], params[1]
    else:
        return "", ""


async def edit_message(
        message: Message,
        text: str = '',
        **kwargs
) -> int:
    kwargs.setdefault('message_id', message.id)
    kwargs.setdefault('message', text)
    kwargs.setdefault('peer_id', message.peer_id)
    kwargs.setdefault('keep_forward_messages', True)
    kwargs.setdefault('keep_snippets', True)
    kwargs.setdefault('dont_parse_links', False)
    response = -1
    try:
        response = await message.api.messages.edit(
            **kwargs
        )
    except:
        sleep(1)
        response = await message.api.messages.edit(
            **kwargs
        )
    return response


def call_method(method, args, arg_count):
    # main token with audio access must be first in Global.DB.tokens
    link = 'https://api.vk.com/method/' + str(method) + '?' + str(args)
    if arg_count > 0:
        link = link + '&'
    link = link + '&access_token=' + Global.DB.tokens[0] + '&v=' + API_VERSION
    answer = post(link)
    return answer


async def getrand():
    return random.randint(0, 1000000000)


def getranda():
    return random.randint(0, 1000000000)


async def getrandomsmile():
    return random.choice(list(SMILES.values()))


async def get_full_name_by_id(member_id: int) -> str:
    if member_id > 0:
        user = (await Global.user.api.users.get(user_ids=member_id))[0]
        return f"{user.first_name} {user.last_name}"
    else:
        group = (await Global.user.api.groups.get_by_id(group_ids=abs(member_id)))[0]
        return group.name


async def get_id_by_reply(message: Message):
    return message.reply_message.from_id


async def get_id_by_domain(
        domain: str,
        obj_types: Iterable[str] = ('user',)
) -> Optional[int]:
    try:
        search = await Global.user.api.utils.resolve_screen_name(screen_name=domain)
        if search.type in obj_types:
            return search.object_id if search.type == 'user' else -search.object_id
    except VKError:
        return None


async def get_ids_by_message(
        message: Message,
        member_id: Optional[int] = None,
        domain: Optional[str] = None
) -> List[int]:
    results = []

    if member_id:
        results.append(member_id)
    if domain:
        result = await get_id_by_domain(domain, ['user', 'group'])
        if result:
            results.append(result)
    if message.reply_message:
        results.append(message.from_id)
    if message.fwd_messages:
        for fwd_msg in message.fwd_messages:
            results.append(fwd_msg.from_id)
    return results


async def get_all_links_from_string(string: str):
    result = []
    result = re.findall(r'\[id\w+\|[^\]]{0,999}\]', string)
    groups = re.findall(r'\[club\w+\|[^\]]{0,999}\]', string)
    for group in groups:
        result.append(group)
    r1 = re.findall(r'https://vk\.com/[^\s]{0,999}', string)
    string = re.sub(r'https://vk\.com/[^\s]{0,999}', '', string)
    r2 = re.findall(r'http://vk\.com/[^\s]{0,999}', string)
    string = re.sub(r'http://vk\.com/[^\s]{0,999}', '', string)
    r3 = re.findall(r'vk\.com/[^\s]{0,999}', string)
    string = re.sub(r'vk\.com/[^\s]{0,999}', '', string)
    tmp = []
    for r in r1:
        tmp.append(r)
    for r in r2:
        tmp.append(r)
    for r in r3:
        tmp.append(r)

    for some in tmp:
        t = re.split(r'vk.com/', some)
        t = t[1]
        trueid = await get_id_by_domain(t, ['user', 'group'])
        formatted = ''
        if trueid >= 0:
            formatted = f'[id{trueid}|GBot!!]'
        elif trueid < 0:
            formatted = f'[club{-trueid}|GBot!!]'
        result.append(formatted)
    return result


async def get_id_from_link(link: str):
    t = re.findall(r'\[id\d+\|', link)
    if len(t) == 0:
        t = re.findall(r'\[club\d+\|', link)
    t = t[0].replace('[', '')
    t = t.replace('|', '')
    if t.find('id') > -1:
        t = t.replace('id', '')
    elif t.find('club') > -1:
        t = t.replace('club', '')
        t = f'-{t}'
    t = int(t)
    return t

