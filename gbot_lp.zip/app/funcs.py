from vars import Global


async def getlabnow():
    if not Global.canwrite:
        return False
    Global.canwrite = False
    Global.user.api.messages.send(peer_id=Global.DB.home_chat_id, message='моя лаб', random_id=0)
    return True

