from vkbottle.rule import AbstractMessageRule
from .utils import *
from .vars import Global


class FromMainBot(AbstractMessageRule):
    async def check(self, message: Message) -> bool:
        if message.from_id == Global.DB.main_bot_id and message.peer_id == Global.DB.home_chat_id:
            return True
        return False


class SelfCommand(AbstractMessageRule):
    async def check(self, message: Message) -> bool:
        if message.from_id == Global.DB.self_id:
            prefix, command = await getparams(message.text)
            if prefix != "" and prefix == Global.DB.prefixes['self_prefix']:
                return True
        return False


class TrustedCommand(AbstractMessageRule):
    async def check(self, message: Message) -> bool:
        if message.from_id in Global.DB.trusted_users:
            prefix, command = await getparams(message.text)
            if prefix != "" and prefix == Global.DB.prefixes['repeat_prefix']:
                return True
        return False


class SelfDeleteCommand(AbstractMessageRule):
    async def check(self, message: Message) -> bool:
        if message.from_id == Global.DB.self_id:
            prefix, command = await getparams(message.text)
            if prefix != "" and prefix == Global.DB.prefixes['delete_prefix']:
                return True
        return False
